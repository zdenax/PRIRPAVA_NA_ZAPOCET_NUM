def laplace_2d_gauss_seidel(n, bc_top, bc_bottom, bc_left, bc_right,
                             tol=1e-8, max_iter=10000, verbose=False):
    """
    Řešení 2D Laplaceovy rovnice na čtvercové mřížce řádu n
    pomocí Gauss-Seidelovy iterační metody.

    Laplaceova rovnice (diskrétní tvar):
        A[i,j] = 0.25 * (A[i-1,j] + A[i+1,j] + A[i,j-1] + A[i,j+1])

    Okrajové podmínky jsou zadány jako skaláry nebo funkce:
      - Skalár:   konstantní hodnota na celém okraji
      - Funkce:   bc_top(j) -> hodnota v j-tém sloupci na horním okraji, atd.

    Indexování matice:
      - i=0       : horní okraj  (bc_top)
      - i=n-1     : dolní okraj  (bc_bottom)
      - j=0       : levý okraj   (bc_left)
      - j=n-1     : pravý okraj  (bc_right)

    :param n:          Řád čtvercové matice (počet řádků = sloupců)
    :param bc_top:     Horní okrajová podmínka (skalár nebo funkce f(j))
    :param bc_bottom:  Dolní okrajová podmínka (skalár nebo funkce f(j))
    :param bc_left:    Levá okrajová podmínka  (skalár nebo funkce f(i))
    :param bc_right:   Pravá okrajová podmínka (skalár nebo funkce f(i))
    :param tol:        Tolerance konvergence (max. změna v jedné iteraci, default 1e-8)
    :param max_iter:   Maximální počet iterací (default 10000)
    :param verbose:    Vypisovat průběh každých 500 iterací (default False)
    :return:           2D seznam (matice) hodnot A[i][j], nebo None při chybě

    Příklad použití — NUM-24-03-22:
        # Matice řádu 50, horní okraj = 100, ostatní okraje = 0
        A = laplace_2d_gauss_seidel(
            n=50,
            bc_top=100,
            bc_bottom=0,
            bc_left=0,
            bc_right=0,
            tol=1e-8,
            max_iter=20000,
            verbose=True
        )
        # Výpis středové hodnoty
        print(A[25][25])
    """

    if n < 3:
        print("Chyba: n musí být alespoň 3 (potřebujeme aspoň 1 vnitřní buňku).")
        return None

    # Převod skalárů na funkce
    def _to_func_j(val):
        return val if callable(val) else (lambda j, v=val: v)

    def _to_func_i(val):
        return val if callable(val) else (lambda i, v=val: v)

    f_top    = _to_func_j(bc_top)
    f_bottom = _to_func_j(bc_bottom)
    f_left   = _to_func_i(bc_left)
    f_right  = _to_func_i(bc_right)

    # Inicializace matice nulami
    A = [[0.0] * n for _ in range(n)]

    # Nastavení okrajů
    for j in range(n):
        A[0][j]   = f_top(j)
        A[n-1][j] = f_bottom(j)
    for i in range(n):
        A[i][0]   = f_left(i)
        A[i][n-1] = f_right(i)

    # Gauss-Seidelova iterace
    for iteration in range(1, max_iter + 1):
        max_change = 0.0

        for i in range(1, n - 1):
            for j in range(1, n - 1):
                old_val = A[i][j]
                A[i][j] = 0.25 * (A[i-1][j] + A[i+1][j] + A[i][j-1] + A[i][j+1])
                change = abs(A[i][j] - old_val)
                if change > max_change:
                    max_change = change

        if verbose and iteration % 500 == 0:
            print(f"Iterace {iteration:6d}: max. změna = {max_change:.4e}")

        if max_change < tol:
            if verbose:
                print(f"Konvergoval v iteraci {iteration}, max. změna = {max_change:.4e}")
            return A

    print(f"Upozornění: Metoda nedosáhla tolerance {tol:.2e} po {max_iter} iteracích.")
    return A


def laplace_2d_jacobi(n, bc_top, bc_bottom, bc_left, bc_right,
                      tol=1e-8, max_iter=10000, verbose=False):
    """
    Alternativní Jacobiho varianta — aktualizuje z kopie, pomalejší konvergence.
    Stejné parametry jako laplace_2d_gauss_seidel.

    :return: 2D seznam hodnot A[i][j], nebo None při chybě
    """
    if n < 3:
        print("Chyba: n musí být alespoň 3.")
        return None

    def _to_func_j(val):
        return val if callable(val) else (lambda j, v=val: v)

    def _to_func_i(val):
        return val if callable(val) else (lambda i, v=val: v)

    f_top    = _to_func_j(bc_top)
    f_bottom = _to_func_j(bc_bottom)
    f_left   = _to_func_i(bc_left)
    f_right  = _to_func_i(bc_right)

    A = [[0.0] * n for _ in range(n)]

    for j in range(n):
        A[0][j]   = f_top(j)
        A[n-1][j] = f_bottom(j)
    for i in range(n):
        A[i][0]   = f_left(i)
        A[i][n-1] = f_right(i)

    for iteration in range(1, max_iter + 1):
        A_new = [row[:] for row in A]
        max_change = 0.0

        for i in range(1, n - 1):
            for j in range(1, n - 1):
                A_new[i][j] = 0.25 * (A[i-1][j] + A[i+1][j] + A[i][j-1] + A[i][j+1])
                change = abs(A_new[i][j] - A[i][j])
                if change > max_change:
                    max_change = change

        A = A_new

        if verbose and iteration % 500 == 0:
            print(f"Iterace {iteration:6d}: max. změna = {max_change:.4e}")

        if max_change < tol:
            if verbose:
                print(f"Konvergoval v iteraci {iteration}, max. změna = {max_change:.4e}")
            return A

    print(f"Upozornění: Jacobiho metoda nedosáhla tolerance {tol:.2e} po {max_iter} iteracích.")
    return A


# ---------------------------------------------------------------------------
# Příklad přímého použití pro NUM-24-03-22:
#   Čtvercová matice 50x50, horní řádek = 100, ostatní okraje = 0
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    N = 50

    A = laplace_2d_gauss_seidel(
        n=N,
        bc_top=100,
        bc_bottom=0,
        bc_left=0,
        bc_right=0,
        tol=1e-8,
        max_iter=20000,
        verbose=True
    )

    if A is not None:
        print(f"\nHodnota středové buňky A[25][25] = {A[25][25]:.6f}")
        print(f"Hodnota A[1][25]  (blízko horního okraje) = {A[1][25]:.6f}")
        print(f"Hodnota A[48][25] (blízko dolního okraje) = {A[48][25]:.6f}")

        # Vypsání části matice (5x5 střed)
        print("\nStředová 5x5 oblast (i=23..27, j=23..27):")
        for i in range(23, 28):
            row_str = "  ".join(f"{A[i][j]:8.4f}" for j in range(23, 28))
            print(f"  i={i}: {row_str}")
