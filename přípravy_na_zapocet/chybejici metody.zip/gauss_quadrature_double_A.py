import math

def gauss_quadrature_double(f, a, b, c_func, d_func, n=5, verbose=False):
    """
    Numerická integrace dvojného integrálu pomocí Gaussovy-Legendreovy kvadratury.

        integral_a^b  integral_{c(x)}^{d(x)}  f(x, y)  dy  dx

    Meze vnitřního integrálu mohou záviset na x (obecná oblast).
    Pro obdélníkovou oblast stačí c_func = lambda x: c, d_func = lambda x: d.

    Uzly a váhy pro n = 2, 3, 4, 5 jsou předpočítány.
    Pro vyšší n použij scipy.special.roots_legendre (nevyžaduje se zde).

    :param f:       Integrovaná funkce f(x, y)
    :param a:       Dolní mez vnějšího integrálu (v x)
    :param b:       Horní mez vnějšího integrálu (v x)
    :param c_func:  Dolní mez vnitřního integrálu — funkce c(x) nebo skalár
    :param d_func:  Horní mez vnitřního integrálu — funkce d(x) nebo skalár
    :param n:       Počet uzlů Gaussovy kvadratury (2–5, default 5)
    :param verbose: Vypisovat mezivýsledky (default False)
    :return:        Odhad dvojného integrálu nebo None při chybě

    Příklad použití — NUM-24-02-16:
        # Hledáme p takové, aby:
        # integral_0^p  integral_0^{2*pi}  e^{-alpha*x} * sin(x)  dx  d_alpha = 1.31848
        #
        # f(alpha, x) = e^{-alpha*x} * sin(x)
        # Vnější integral přes alpha od 0 do p
        # Vnitřní integral přes x od 0 do 2*pi
        #
        # from gauss_quadrature_double import gauss_quadrature_double
        # from bisekce import bisection
        # import math
        #
        # def integrand(alpha, x):
        #     return math.exp(-alpha * x) * math.sin(x)
        #
        # def F(p):
        #     if p <= 0:
        #         return -1.31848
        #     val = gauss_quadrature_double(
        #         f=integrand,
        #         a=0.0, b=p,
        #         c_func=0.0, d_func=2*math.pi,
        #         n=5
        #     )
        #     return val - 1.31848
        #
        # p_result = bisection(F, 0.01, 20.0, tol=1e-8, max_iter=100, verbose=True)
        # print(f"p = {p_result:.8f}")
    """

    # Gaussovy-Legendreovy uzly a váhy na [-1, 1]
    GL_NODES = {
        2: (
            [-math.sqrt(1/3), math.sqrt(1/3)],
            [1.0, 1.0]
        ),
        3: (
            [-math.sqrt(3/5), 0.0, math.sqrt(3/5)],
            [5/9, 8/9, 5/9]
        ),
        4: (
            [-0.861136311594953, -0.339981043584856,
              0.339981043584856,  0.861136311594953],
            [ 0.347854845137454,  0.652145154862626,
              0.652145154862626,  0.347854845137454]
        ),
        5: (
            [-0.906179845938664, -0.538469310105683, 0.0,
              0.538469310105683,  0.906179845938664],
            [ 0.236926885056189,  0.478628670499366, 0.568888888888889,
              0.478628670499366,  0.236926885056189]
        ),
    }

    if n not in GL_NODES:
        print(f"Chyba: Nepodporovaný počet uzlů n={n}. Použij 2, 3, 4 nebo 5.")
        return None

    if f is None or a is None or b is None or c_func is None or d_func is None:
        print("Chyba: Vstupní hodnoty nesmí být None.")
        return None

    if a >= b:
        print("Chyba: a musí být menší než b.")
        return None

    # Převod skalárů na funkce
    c_fn = c_func if callable(c_func) else (lambda x, v=c_func: v)
    d_fn = d_func if callable(d_func) else (lambda x, v=d_func: v)

    nodes, weights = GL_NODES[n]

    # Transformace: t v [-1,1] -> x v [a,b]
    m_x     = 0.5 * (a + b)
    half_x  = 0.5 * (b - a)

    result = 0.0

    for i, (t_i, w_i) in enumerate(zip(nodes, weights)):
        x_i = m_x + half_x * t_i
        c_i = c_fn(x_i)
        d_i = d_fn(x_i)

        if c_i >= d_i:
            if verbose:
                print(f"  Uzel x={x_i:.6f}: c(x) >= d(x), příspěvek = 0")
            continue

        # Transformace: s v [-1,1] -> y v [c_i, d_i]
        m_y    = 0.5 * (c_i + d_i)
        half_y = 0.5 * (d_i - c_i)

        inner = 0.0
        for j, (t_j, w_j) in enumerate(zip(nodes, weights)):
            y_j = m_y + half_y * t_j
            fval = f(x_i, y_j)
            if math.isnan(fval) or math.isinf(fval):
                print(f"Chyba: f({x_i:.4f}, {y_j:.4f}) vrátila NaN nebo Inf.")
                return None
            inner += w_j * fval

        inner *= half_y

        if verbose:
            print(f"  Uzel x={x_i:.6f}: vnitřní integral = {inner:.8f}")

        result += w_i * inner

    result *= half_x

    if math.isnan(result) or math.isinf(result):
        print("Chyba: Výsledek integrace je NaN nebo Inf.")
        return None

    return result


def gauss_quadrature_1d(f, a, b, n=5):
    """
    Pomocná 1D Gaussova kvadratura (stejné uzly jako dvojná verze).
    Vhodná pro vnořené volání nebo samostatné použití.

    :param f: Funkce f(x)
    :param a: Dolní mez
    :param b: Horní mez
    :param n: Počet uzlů (2–5, default 5)
    :return:  Odhad integrálu nebo None při chybě
    """
    return gauss_quadrature_double(
        f=lambda x, _y: f(x),
        a=a, b=b,
        c_func=0.0, d_func=1.0,
        n=n
    )
    # Pozn.: Výše je hack — raději použij přímo gauss_quadrature z 03_soustavy...


# ---------------------------------------------------------------------------
# Příklad přímého použití pro NUM-24-02-16:
#   Najdi p: integral_0^p integral_0^{2pi} e^{-alpha*x} sin(x) dx d_alpha = 1.31848
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__),
                                    '..', '01_nelinearni_rovnice'))
    from bisekce import bisection

    TARGET = 1.31848

    def integrand(alpha, x):
        if alpha * x > 700:          # Ochrana před přetečením exp
            return 0.0
        return math.exp(-alpha * x) * math.sin(x)

    def F(p):
        if p <= 1e-12:
            return -TARGET
        val = gauss_quadrature_double(
            f=integrand,
            a=0.0, b=p,
            c_func=0.0, d_func=2 * math.pi,
            n=5
        )
        if val is None:
            return float('nan')
        return val - TARGET

    # Nejprve odhadneme interval — funkce F je monotonní, ale konverguje,
    # takže TARGET=1.31848 leží zhruba mezi p=5.5 a p=6.5
    print("Hledáme p pro dvojný integrál = 1.31848 ...")
    p_result = bisection(F, a=5.5, b=6.5, tol=1e-8, max_iter=200, verbose=True)

    if p_result is not None:
        val_check = gauss_quadrature_double(
            f=integrand,
            a=0.0, b=p_result,
            c_func=0.0, d_func=2 * math.pi,
            n=5
        )
        print(f"\np = {p_result:.8f}")
        print(f"Ověření integrálu: {val_check:.8f}  (cíl: {TARGET})")
        print(f"Chyba: {abs(val_check - TARGET):.2e}")
