import math

def shooting_method(f, x0, x_end, y0, bc_func, h=0.01, tol=1e-8, max_iter=100, verbose=False):
    """
    Metoda střelby (shooting method) pro okrajové úlohy (BVP).

    Řeší ODR y' = f(x, y) s okrajovou podmínkou zadanou jako bc_func(body) = 0,
    kde body je seznam (x, y) vrácený RK4.

    Okrajová podmínka může být libovolná — například:
      - y(x_end) == cílová hodnota  =>  bc_func = lambda pts: pts[-1][1] - cilova_hodnota
      - integral y(x) dx = K        =>  bc_func = lambda pts: integral(pts) - K

    Hledáme počáteční podmínku y'(x0) = s tak, aby bc_func byla splněna.
    Iteruje bisekci na s_low a s_high.

    :param f:        Funkce f(x, y, s) nebo f(x, y) — pravá strana soustavy.
                     Pokud ODR závisí na počáteční hodnotě y'(x0)=s, předej
                     ji přes uzávěr (closure), viz příklad níže.
    :param x0:       Počáteční bod x
    :param x_end:    Koncový bod x
    :param y0:       Počáteční hodnota y(x0) — pevná okrajová podmínka na levém konci
    :param bc_func:  Funkce bc_func(points) -> float.
                     Vrací 0, pokud je okrajová podmínka splněna.
                     points je seznam n-tic (x, y).
    :param h:        Krok integrace RK4 (default 0.01)
    :param tol:      Tolerance pro splnění okrajové podmínky (default 1e-8)
    :param max_iter: Maximální počet iterací bisekce (default 100)
    :param verbose:  Vypisovat průběh (default False)
    :return:         Tuple (s_opt, points) — optimální počáteční sklon a řešení,
                     nebo (None, None) při chybě

    Příklad použití — NUM-24-12-20:
        # y'(x) - y + x = 0, tj. y' = y - x
        # Podmínka: integral_0^1 y(x) dx = 2
        # Obecné řešení: y = C*e^x + x + 1, integral = C*(e-1) + 1.5 = 2 => C = 0.5/(e-1)
        #
        # def make_f(s):
        #     def f(x, y):
        #         return y - x       # y' = y - x
        #     return f
        #
        # def bc(points):
        #     # Lichoběžníkové pravidlo pro integral
        #     integral = 0.0
        #     for i in range(len(points) - 1):
        #         x1, y1 = points[i]
        #         x2, y2 = points[i+1]
        #         integral += 0.5 * (y1 + y2) * (x2 - x1)
        #     return integral - 2.0
        #
        # s_opt, pts = shooting_method(
        #     f=None,          # f se předává přes make_f do solve_with_s
        #     x0=0.0, x_end=1.0, y0=None,  # y0 je taky neznámé — viz varianta níže
        #     bc_func=bc
        # )
        # -- Nebo přímo: --
        # s_opt, pts = shooting_method_integral(bc_target=2.0)
    """

    def _rk4_solve(f_func, x_start, y_start, step, n_steps):
        """Interní RK4 solver, vrací seznam (x, y)."""
        points = [(x_start, y_start)]
        x = x_start
        y = y_start
        for _ in range(n_steps):
            k1 = f_func(x, y)
            k2 = f_func(x + 0.5*step, y + 0.5*step*k1)
            k3 = f_func(x + 0.5*step, y + 0.5*step*k2)
            k4 = f_func(x + step, y + step*k3)
            if any(math.isnan(k) or math.isinf(k) for k in (k1, k2, k3, k4)):
                return None
            y = y + (step/6.0)*(k1 + 2*k2 + 2*k3 + k4)
            x = x + step
            points.append((x, y))
        return points

    n_steps = max(1, round((x_end - x0) / h))

    # f musí být funkce tvaru f(x, y) — počáteční sklon y'(x0)=s
    # je zakódován přes y0 nebo přes closure v f.
    # Zde bisekujeme y0 (počáteční hodnotu y), pokud y0=None,
    # jinak bisekujeme první složku — viz dokumentace výše.
    #
    # Tato implementace bisekuje počáteční hodnotu y(x0) = s (shooting na y0).

    def residual(s):
        pts = _rk4_solve(f, x0, s, h, n_steps)
        if pts is None:
            return float('nan')
        return bc_func(pts)

    if y0 is None:
        s_low, s_high = -1e3, 1e3
    else:
        # Hledáme korekci kolem y0
        s_low = y0 - 1e3
        s_high = y0 + 1e3

    r_low  = residual(s_low)
    r_high = residual(s_high)

    if math.isnan(r_low) or math.isnan(r_high):
        print("Chyba: bc_func vrátila NaN pro počáteční interval.")
        return None, None

    # Rozšíř interval pokud nutno
    expand = 0
    while r_low * r_high > 0 and expand < 30:
        s_low  *= 2.0
        s_high *= 2.0
        r_low   = residual(s_low)
        r_high  = residual(s_high)
        expand += 1

    if r_low * r_high > 0:
        print("Chyba: Nepodařilo se najít interval se změnou znaménka pro shooting.")
        return None, None

    s_opt = s_low
    for i in range(max_iter):
        s_mid = 0.5 * (s_low + s_high)
        r_mid = residual(s_mid)

        if verbose:
            print(f"Iterace {i+1:3d}: s = {s_mid:.10f}, bc_residual = {r_mid:.4e}")

        if abs(r_mid) < tol:
            s_opt = s_mid
            if verbose:
                print(f"Konvergoval v iteraci {i+1}, s = {s_opt:.10f}")
            break

        if r_low * r_mid < 0:
            s_high = s_mid
            r_high = r_mid
        else:
            s_low = s_mid
            r_low = r_mid
        s_opt = s_mid
    else:
        print("Upozornění: Metoda střelby nedosáhla požadované tolerance.")

    final_points = _rk4_solve(f, x0, s_opt, h, n_steps)
    return s_opt, final_points


# ---------------------------------------------------------------------------
# Příklad přímého použití pro NUM-24-12-20:
#   y'(x) - y + x = 0, podmínka: integral_0^1 y(x)dx = 2
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # y' = y - x
    def ode(x, y):
        return y - x

    def trapezoid_integral(points):
        total = 0.0
        for i in range(len(points) - 1):
            x1, y1 = points[i]
            x2, y2 = points[i+1]
            total += 0.5 * (y1 + y2) * (x2 - x1)
        return total

    def bc(points):
        return trapezoid_integral(points) - 2.0

    s_opt, pts = shooting_method(
        f=ode,
        x0=0.0,
        x_end=1.0,
        y0=None,       # hledáme y(0) = s
        bc_func=bc,
        h=0.001,
        tol=1e-10,
        verbose=True
    )

    if pts is not None:
        print(f"\ny(0) = {s_opt:.10f}")
        print(f"y(1) = {pts[-1][1]:.10f}")
        integ = trapezoid_integral(pts)
        print(f"Integral y(x) dx od 0 do 1 = {integ:.10f}  (cíl: 2.0)")

        # Analytické řešení: y = C*e^x + x + 1, kde C = 0.5/(e-1)
        import math
        C = 0.5 / (math.e - 1)
        y0_exact = C + 1.0
        print(f"\nAnalytické y(0) = {y0_exact:.10f}")
        print(f"Chyba: {abs(s_opt - y0_exact):.2e}")
